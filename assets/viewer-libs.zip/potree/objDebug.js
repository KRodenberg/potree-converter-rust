import {FileLoader} from '../three.js/build/three.module.js';

function getPositionCount(child) {
	let geometry = child.geometry;
	let position = geometry && geometry.attributes && geometry.attributes.position;

	return position ? position.count : 0;
}

function getTriangleCount(child) {
	let geometry = child.geometry;
	let positionCount = getPositionCount(child);
	let indexCount = geometry && geometry.index ? geometry.index.count : positionCount;

	return Math.floor(indexCount / 3);
}

function getLineSegmentCount(child) {
	let positionCount = getPositionCount(child);

	if(child.isLineSegments){
		return Math.floor(positionCount / 2);
	}

	return Math.max(0, positionCount - 1);
}

function getMaterials(child) {
	if(!child.material){
		return [];
	}

	return Array.isArray(child.material) ? child.material : [child.material];
}

function isLineObject(child) {
	return child.isLine || child.isLineSegments || child.isLineLoop || child.isLine2 || child.isLineSegments2;
}

function setObjLineSnapping(object, enabled) {
	let count = 0;

	object.traverse((child) => {
		if(!isLineObject(child)){
			return;
		}

		child.userData = child.userData || {};

		if(enabled){
			if(child.userData.potreeOriginalRaycast){
				child.raycast = child.userData.potreeOriginalRaycast;
				delete child.userData.potreeOriginalRaycast;
			}

			child.userData.potreeLineSnapDisabled = false;
		}else{
			if(!child.userData.potreeOriginalRaycast){
				child.userData.potreeOriginalRaycast = child.raycast;
			}

			child.raycast = function(){};
			child.userData.potreeLineSnapDisabled = true;
		}

		count++;
	});

	return count;
}

function describeObj(name, object) {
	let summary = {
		name: name,
		meshes: 0,
		lines: 0,
		points: 0,
		meshVertices: 0,
		lineVertices: 0,
		triangles: 0,
		lineSegments: 0,
		wireframeMaterials: 0,
		transparentMaterials: 0,
		hiddenObjects: 0,
		lineSnapDisabled: 0
	};

	object.traverse((child) => {
		if(child.visible === false){
			summary.hiddenObjects++;
		}

		if(child.isMesh){
			summary.meshes++;
			summary.meshVertices += getPositionCount(child);
			summary.triangles += getTriangleCount(child);

			for(let material of getMaterials(child)){
				if(material.wireframe){
					summary.wireframeMaterials++;
				}

				if(material.transparent || material.opacity < 1){
					summary.transparentMaterials++;
				}
			}
		}else if(isLineObject(child)){
			summary.lines++;
			summary.lineVertices += getPositionCount(child);
			summary.lineSegments += getLineSegmentCount(child);

			if(child.userData && child.userData.potreeLineSnapDisabled){
				summary.lineSnapDisabled++;
			}
		}else if(child.isPoints){
			summary.points++;
		}
	});

	console.table([summary]);

	return summary;
}

function eachObjChild(callback) {
	for(let object of Object.values(window.potreeObjModels || {})){
		object.traverse(callback);
	}
}

export function installObjDebug() {
	window.potreeObjModels = window.potreeObjModels || {};

	if(window.potreeDebug && window.potreeDebug.__objDebugInstalled){
		return;
	}

	window.potreeDebug = Object.assign(window.potreeDebug || {}, {
		__objDebugInstalled: true,
		describeObj: describeObj,
		describeObjModels(){
			return Object.entries(window.potreeObjModels).map(([name, object]) => {
				return describeObj(name, object);
			});
		},
		showOnlyMeshes(){
			eachObjChild((child) => {
				if(child.isMesh){
					child.visible = true;
				}else if(isLineObject(child)){
					child.visible = false;
				}
			});

			return this.describeObjModels();
		},
		showOnlyLines(){
			eachObjChild((child) => {
				if(child.isMesh){
					child.visible = false;
				}else if(isLineObject(child)){
					child.visible = true;
				}
			});

			return this.describeObjModels();
		},
		showAllObjGeometry(){
			eachObjChild((child) => {
				if(child.isMesh || isLineObject(child)){
					child.visible = true;
				}
			});

			return this.describeObjModels();
		},
		disableLineSnapping(){
			let count = 0;

			for(let object of Object.values(window.potreeObjModels || {})){
				count += disableObjLineSnapping(object);
			}

			console.log(`Disabled OBJ line snapping on ${count} line objects.`);
			return this.describeObjModels();
		},
		enableLineSnapping(){
			let count = 0;

			for(let object of Object.values(window.potreeObjModels || {})){
				count += enableObjLineSnapping(object);
			}

			console.log(`Enabled OBJ line snapping on ${count} line objects.`);
			return this.describeObjModels();
		}
	});
}

export function splitMixedObjPrimitives(text) {
	let output = [];
	let currentPrimitive = null;
	let primitiveBlockCount = 0;

	for(let line of text.split(/\r?\n/)){
		let trimmed = line.trim();
		let primitive = null;

		if(/^f\s+/.test(trimmed)){
			primitive = 'mesh';
		}else if(/^l\s+/.test(trimmed)){
			primitive = 'line';
		}else if(/^p\s+/.test(trimmed)){
			primitive = 'points';
		}else if(/^[og](\s+|$)/.test(trimmed)){
			currentPrimitive = null;
		}

		if(primitive && primitive !== currentPrimitive){
			primitiveBlockCount++;
			output.push(`g __potree_${primitive}_${primitiveBlockCount}`);
			currentPrimitive = primitive;
		}

		output.push(line);
	}

	return {
		text: output.join('\n'),
		primitiveBlockCount: primitiveBlockCount
	};
}

export function loadObjWithMixedPrimitives(url, objLoader, onLoad, onProgress, onError) {
	let fileLoader = new FileLoader(objLoader.manager);

	if(objLoader.path !== undefined){
		fileLoader.setPath(objLoader.path);
	}

	if(objLoader.requestHeader !== undefined){
		fileLoader.setRequestHeader(objLoader.requestHeader);
	}

	if(objLoader.withCredentials !== undefined){
		fileLoader.setWithCredentials(objLoader.withCredentials);
	}

	fileLoader.load(url, (text) => {
		let split = splitMixedObjPrimitives(text);

		if(split.primitiveBlockCount > 1){
			console.log(`OBJ split into ${split.primitiveBlockCount} line/mesh primitive blocks before parsing: ${url}`);
		}

		onLoad(objLoader.parse(split.text));
	}, onProgress, onError);
}

export function registerObjModel(name, object) {
	installObjDebug();

	window.potreeObjModels[name] = object;

	return describeObj(name, object);
}

export function disableObjLineSnapping(object) {
	return setObjLineSnapping(object, false);
}

export function enableObjLineSnapping(object) {
	return setObjLineSnapping(object, true);
}
